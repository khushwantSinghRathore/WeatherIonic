export const environment = {
  production: true,
  apiKey: 'IhDZPlGKi0NTqkekviWrcEmWmrhXyarl'
};
