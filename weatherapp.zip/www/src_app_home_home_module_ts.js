"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 2003);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_apicalls_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/apicalls.service */ 1427);
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! dateformat */ 3659);






let HomePage = class HomePage {
    constructor(apicall) {
        this.apicall = apicall;
        this.now = new Date();
    }
    ngOnInit() {
        this.apicall.location.subscribe(res => {
            var _a;
            this.locationdata = res;
            this.city = (_a = this.locationdata) === null || _a === void 0 ? void 0 : _a.EnglishName;
            console.log(this.city);
        });
        this.apicall.currentweather.subscribe(res => {
            var _a, _b;
            this.citywether = res;
            this.localtime = (0,dateformat__WEBPACK_IMPORTED_MODULE_3__["default"])((_a = this.citywether) === null || _a === void 0 ? void 0 : _a.LocalObservationDateTime, 'dddd,dd mmmm');
            this.img = this.getImg((_b = this.citywether) === null || _b === void 0 ? void 0 : _b.WeatherIcon);
        });
        this.apicall.forecastweather.subscribe(res => {
            this.forecastdata = res;
        });
    }
    getname() {
        if (this.city) {
            console.log(this.city);
            this.apicall.getcitydata(this.city).subscribe(res => {
                var _a, _b;
                this.locationdata = res.data[0];
                console.log(this.locationdata);
                localStorage.setItem('location', JSON.stringify(this.locationdata));
                this.apicall.getcurrentweather((_a = this.locationdata) === null || _a === void 0 ? void 0 : _a.Key).subscribe(resp => {
                    var _a;
                    this.citywether = resp.data[0];
                    console.log(this.citywether);
                    this.img = this.getImg((_a = this.citywether) === null || _a === void 0 ? void 0 : _a.WeatherIcon);
                    localStorage.setItem('currentweather', JSON.stringify(this.citywether));
                    this.localtime = (0,dateformat__WEBPACK_IMPORTED_MODULE_3__["default"])(this.citywether.LocalObservationDateTime, 'dddd,dd mmmm');
                });
                this.apicall.getforecast((_b = this.locationdata) === null || _b === void 0 ? void 0 : _b.Key).subscribe(resp => {
                    this.forecastdata = resp.data.DailyForecasts;
                    console.log(this.forecastdata);
                    localStorage.setItem('forecastweather', JSON.stringify(this.forecastdata));
                });
            });
        }
        else {
            console.log('empty');
        }
    }
    getDay(daystring) {
        return (0,dateformat__WEBPACK_IMPORTED_MODULE_3__["default"])(daystring, 'dddd');
    }
    getCelsius(temp) {
        return this.truncate((temp - 32) * 0.5556, 1);
    }
    truncate(num, places) {
        return Math.trunc(num * Math.pow(10, places)) / Math.pow(10, places);
    }
    getImg(num) {
        if (num === 1 || num === 2 || num === 33 || num === 34 || num === 30) {
            return 'assets/images/clear-sky.png';
        }
        else if (num === 3 || num === 5 || num === 6 || num === 35 || num === 37) {
            return 'assets/images/few-clouds.png';
        }
        else if (num === 7 || num === 8 || num === 19 || num === 20 || num === 21 || num === 43 || num === 38) {
            return 'assets/images/broken-clouds.png';
        }
        else if (num === 42 || num === 41 || num === 17 || num === 16 || num === 15 || num === 32) {
            return 'assets/images/thunderstorm.png';
        }
        else if (num === 18 || num === 26 || num === 29) {
            return 'assets/images/rain.png';
        }
        else if (num === 4 || num === 36) {
            return 'assets/images/scattered-clouds.png';
        }
        else if (num === 11 || num === 25 || num === 43) {
            return 'assets/images/mist.png';
        }
        else if (num === 44 || num === 29 || num === 23 || num === 31 || num === 22) {
            return 'assets/images/snow.png';
        }
        else {
            return 'assets/images/shower-rain.png';
        }
    }
};
HomePage.ctorParameters = () => [
    { type: _services_apicalls_service__WEBPACK_IMPORTED_MODULE_2__.ApicallsService }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 1427:
/*!**********************************************!*\
  !*** ./src/app/services/apicalls.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApicallsService": () => (/* binding */ ApicallsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor-community/http */ 2909);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ 2340);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 4505);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 4383);





let ApicallsService = class ApicallsService {
    constructor() {
        this.location = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(JSON.parse(localStorage.getItem('location')));
        this.currentweather = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(JSON.parse(localStorage.getItem('currentweather')));
        this.forecastweather = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(JSON.parse(localStorage.getItem('forecastweather')));
    }
    getcitydata(city) {
        const option = {
            url: 'http://dataservice.accuweather.com/locations/v1/cities/search',
            headers: {},
            params: { apikey: _environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiKey, q: city },
        };
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.from)(_capacitor_community_http__WEBPACK_IMPORTED_MODULE_0__.Http.get(option));
    }
    getcurrentweather(locationkey) {
        const option = {
            url: 'http://dataservice.accuweather.com/currentconditions/v1/' + locationkey,
            headers: {},
            params: { apikey: _environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiKey, details: 'true' },
        };
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.from)(_capacitor_community_http__WEBPACK_IMPORTED_MODULE_0__.Http.get(option));
    }
    getforecast(locationkey) {
        const option = {
            url: 'http://dataservice.accuweather.com/forecasts/v1/daily/5day/' + locationkey,
            headers: {},
            params: { apikey: _environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.apiKey, details: 'true' },
        };
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.from)(_capacitor_community_http__WEBPACK_IMPORTED_MODULE_0__.Http.get(option));
    }
};
ApicallsService.ctorParameters = () => [];
ApicallsService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], ApicallsService);



/***/ }),

/***/ 4977:
/*!************************************************************************!*\
  !*** ./node_modules/@capacitor-community/http/dist/esm/definitions.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 2909:
/*!******************************************************************!*\
  !*** ./node_modules/@capacitor-community/http/dist/esm/index.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Http": () => (/* binding */ Http)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 4977);

const Http = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Http', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor-community_http_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 2575)).then(m => new m.HttpWeb()),
    electron: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor-community_http_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 2575)).then(m => new m.HttpWeb()),
});




/***/ }),

/***/ 5099:
/*!****************************************************!*\
  !*** ./node_modules/@capacitor/core/dist/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Capacitor": () => (/* binding */ Capacitor),
/* harmony export */   "CapacitorException": () => (/* binding */ CapacitorException),
/* harmony export */   "CapacitorPlatforms": () => (/* binding */ CapacitorPlatforms),
/* harmony export */   "ExceptionCode": () => (/* binding */ ExceptionCode),
/* harmony export */   "Plugins": () => (/* binding */ Plugins),
/* harmony export */   "WebPlugin": () => (/* binding */ WebPlugin),
/* harmony export */   "WebView": () => (/* binding */ WebView),
/* harmony export */   "addPlatform": () => (/* binding */ addPlatform),
/* harmony export */   "registerPlugin": () => (/* binding */ registerPlugin),
/* harmony export */   "registerWebPlugin": () => (/* binding */ registerWebPlugin),
/* harmony export */   "setPlatform": () => (/* binding */ setPlatform)
/* harmony export */ });
/* harmony import */ var A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);


/*! Capacitor: https://capacitorjs.com/ - MIT License */
const createCapacitorPlatforms = win => {
  const defaultPlatformMap = new Map();
  defaultPlatformMap.set('web', {
    name: 'web'
  });
  const capPlatforms = win.CapacitorPlatforms || {
    currentPlatform: {
      name: 'web'
    },
    platforms: defaultPlatformMap
  };

  const addPlatform = (name, platform) => {
    capPlatforms.platforms.set(name, platform);
  };

  const setPlatform = name => {
    if (capPlatforms.platforms.has(name)) {
      capPlatforms.currentPlatform = capPlatforms.platforms.get(name);
    }
  };

  capPlatforms.addPlatform = addPlatform;
  capPlatforms.setPlatform = setPlatform;
  return capPlatforms;
};

const initPlatforms = win => win.CapacitorPlatforms = createCapacitorPlatforms(win);
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */


const CapacitorPlatforms = /*#__PURE__*/initPlatforms(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {});
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */

const addPlatform = CapacitorPlatforms.addPlatform;
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */

const setPlatform = CapacitorPlatforms.setPlatform;

const legacyRegisterWebPlugin = (cap, webPlugin) => {
  var _a;

  const config = webPlugin.config;
  const Plugins = cap.Plugins;

  if (!config || !config.name) {
    // TODO: add link to upgrade guide
    throw new Error(`Capacitor WebPlugin is using the deprecated "registerWebPlugin()" function, but without the config. Please use "registerPlugin()" instead to register this web plugin."`);
  } // TODO: add link to upgrade guide


  console.warn(`Capacitor plugin "${config.name}" is using the deprecated "registerWebPlugin()" function`);

  if (!Plugins[config.name] || ((_a = config === null || config === void 0 ? void 0 : config.platforms) === null || _a === void 0 ? void 0 : _a.includes(cap.getPlatform()))) {
    // Add the web plugin into the plugins registry if there already isn't
    // an existing one. If it doesn't already exist, that means
    // there's no existing native implementation for it.
    // - OR -
    // If we already have a plugin registered (meaning it was defined in the native layer),
    // then we should only overwrite it if the corresponding web plugin activates on
    // a certain platform. For example: Geolocation uses the WebPlugin on Android but not iOS
    Plugins[config.name] = webPlugin;
  }
};

var ExceptionCode;

(function (ExceptionCode) {
  /**
   * API is not implemented.
   *
   * This usually means the API can't be used because it is not implemented for
   * the current platform.
   */
  ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
  /**
   * API is not available.
   *
   * This means the API can't be used right now because:
   *   - it is currently missing a prerequisite, such as network connectivity
   *   - it requires a particular platform or browser version
   */

  ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));

class CapacitorException extends Error {
  constructor(message, code) {
    super(message);
    this.message = message;
    this.code = code;
  }

}

const getPlatformId = win => {
  var _a, _b;

  if (win === null || win === void 0 ? void 0 : win.androidBridge) {
    return 'android';
  } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
    return 'ios';
  } else {
    return 'web';
  }
};

const createCapacitor = win => {
  var _a, _b, _c, _d, _e;

  const capCustomPlatform = win.CapacitorCustomPlatform || null;
  const cap = win.Capacitor || {};
  const Plugins = cap.Plugins = cap.Plugins || {};
  /**
   * @deprecated Use `capCustomPlatform` instead, default functions like registerPlugin will function with the new object.
   */

  const capPlatforms = win.CapacitorPlatforms;

  const defaultGetPlatform = () => {
    return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
  };

  const getPlatform = ((_a = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _a === void 0 ? void 0 : _a.getPlatform) || defaultGetPlatform;

  const defaultIsNativePlatform = () => getPlatform() !== 'web';

  const isNativePlatform = ((_b = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _b === void 0 ? void 0 : _b.isNativePlatform) || defaultIsNativePlatform;

  const defaultIsPluginAvailable = pluginName => {
    const plugin = registeredPlugins.get(pluginName);

    if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
      // JS implementation available for the current platform.
      return true;
    }

    if (getPluginHeader(pluginName)) {
      // Native implementation available.
      return true;
    }

    return false;
  };

  const isPluginAvailable = ((_c = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _c === void 0 ? void 0 : _c.isPluginAvailable) || defaultIsPluginAvailable;

  const defaultGetPluginHeader = pluginName => {
    var _a;

    return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find(h => h.name === pluginName);
  };

  const getPluginHeader = ((_d = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _d === void 0 ? void 0 : _d.getPluginHeader) || defaultGetPluginHeader;

  const handleError = err => win.console.error(err);

  const pluginMethodNoop = (_target, prop, pluginName) => {
    return Promise.reject(`${pluginName} does not have an implementation of "${prop}".`);
  };

  const registeredPlugins = new Map();

  const defaultRegisterPlugin = (pluginName, jsImplementations = {}) => {
    const registeredPlugin = registeredPlugins.get(pluginName);

    if (registeredPlugin) {
      console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
      return registeredPlugin.proxy;
    }

    const platform = getPlatform();
    const pluginHeader = getPluginHeader(pluginName);
    let jsImplementation;

    const loadPluginImplementation = /*#__PURE__*/function () {
      var _ref = (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        if (!jsImplementation && platform in jsImplementations) {
          jsImplementation = typeof jsImplementations[platform] === 'function' ? jsImplementation = yield jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
        } else if (capCustomPlatform !== null && !jsImplementation && 'web' in jsImplementations) {
          jsImplementation = typeof jsImplementations['web'] === 'function' ? jsImplementation = yield jsImplementations['web']() : jsImplementation = jsImplementations['web'];
        }

        return jsImplementation;
      });

      return function loadPluginImplementation() {
        return _ref.apply(this, arguments);
      };
    }();

    const createPluginMethod = (impl, prop) => {
      var _a, _b;

      if (pluginHeader) {
        const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find(m => prop === m.name);

        if (methodHeader) {
          if (methodHeader.rtype === 'promise') {
            return options => cap.nativePromise(pluginName, prop.toString(), options);
          } else {
            return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
          }
        } else if (impl) {
          return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
        }
      } else if (impl) {
        return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
      } else {
        throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
      }
    };

    const createPluginMethodWrapper = prop => {
      let remove;

      const wrapper = (...args) => {
        const p = loadPluginImplementation().then(impl => {
          const fn = createPluginMethod(impl, prop);

          if (fn) {
            const p = fn(...args);
            remove = p === null || p === void 0 ? void 0 : p.remove;
            return p;
          } else {
            throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
          }
        });

        if (prop === 'addListener') {
          p.remove = /*#__PURE__*/(0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            return remove();
          });
        }

        return p;
      }; // Some flair ✨


      wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;

      Object.defineProperty(wrapper, 'name', {
        value: prop,
        writable: false,
        configurable: false
      });
      return wrapper;
    };

    const addListener = createPluginMethodWrapper('addListener');
    const removeListener = createPluginMethodWrapper('removeListener');

    const addListenerNative = (eventName, callback) => {
      const call = addListener({
        eventName
      }, callback);

      const remove = /*#__PURE__*/function () {
        var _ref3 = (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          const callbackId = yield call;
          removeListener({
            eventName,
            callbackId
          }, callback);
        });

        return function remove() {
          return _ref3.apply(this, arguments);
        };
      }();

      const p = new Promise(resolve => call.then(() => resolve({
        remove
      })));
      p.remove = /*#__PURE__*/(0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        console.warn(`Using addListener() without 'await' is deprecated.`);
        yield remove();
      });
      return p;
    };

    const proxy = new Proxy({}, {
      get(_, prop) {
        switch (prop) {
          // https://github.com/facebook/react/issues/20030
          case '$$typeof':
            return undefined;

          case 'toJSON':
            return () => ({});

          case 'addListener':
            return pluginHeader ? addListenerNative : addListener;

          case 'removeListener':
            return removeListener;

          default:
            return createPluginMethodWrapper(prop);
        }
      }

    });
    Plugins[pluginName] = proxy;
    registeredPlugins.set(pluginName, {
      name: pluginName,
      proxy,
      platforms: new Set([...Object.keys(jsImplementations), ...(pluginHeader ? [platform] : [])])
    });
    return proxy;
  };

  const registerPlugin = ((_e = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _e === void 0 ? void 0 : _e.registerPlugin) || defaultRegisterPlugin; // Add in convertFileSrc for web, it will already be available in native context

  if (!cap.convertFileSrc) {
    cap.convertFileSrc = filePath => filePath;
  }

  cap.getPlatform = getPlatform;
  cap.handleError = handleError;
  cap.isNativePlatform = isNativePlatform;
  cap.isPluginAvailable = isPluginAvailable;
  cap.pluginMethodNoop = pluginMethodNoop;
  cap.registerPlugin = registerPlugin;
  cap.Exception = CapacitorException;
  cap.DEBUG = !!cap.DEBUG;
  cap.isLoggingEnabled = !!cap.isLoggingEnabled; // Deprecated props

  cap.platform = cap.getPlatform();
  cap.isNative = cap.isNativePlatform();
  return cap;
};

const initCapacitorGlobal = win => win.Capacitor = createCapacitor(win);

const Capacitor = /*#__PURE__*/initCapacitorGlobal(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {});
const registerPlugin = Capacitor.registerPlugin;
/**
 * @deprecated Provided for backwards compatibility for Capacitor v2 plugins.
 * Capacitor v3 plugins should import the plugin directly. This "Plugins"
 * export is deprecated in v3, and will be removed in v4.
 */

const Plugins = Capacitor.Plugins;
/**
 * Provided for backwards compatibility. Use the registerPlugin() API
 * instead, and provide the web plugin as the "web" implmenetation.
 * For example
 *
 * export const Example = registerPlugin('Example', {
 *   web: () => import('./web').then(m => new m.Example())
 * })
 *
 * @deprecated Deprecated in v3, will be removed from v4.
 */

const registerWebPlugin = plugin => legacyRegisterWebPlugin(Capacitor, plugin);
/**
 * Base class web plugins should extend.
 */


class WebPlugin {
  constructor(config) {
    this.listeners = {};
    this.windowListeners = {};

    if (config) {
      // TODO: add link to upgrade guide
      console.warn(`Capacitor WebPlugin "${config.name}" config object was deprecated in v3 and will be removed in v4.`);
      this.config = config;
    }
  }

  addListener(eventName, listenerFunc) {
    var _this = this;

    const listeners = this.listeners[eventName];

    if (!listeners) {
      this.listeners[eventName] = [];
    }

    this.listeners[eventName].push(listenerFunc); // If we haven't added a window listener for this event and it requires one,
    // go ahead and add it

    const windowListener = this.windowListeners[eventName];

    if (windowListener && !windowListener.registered) {
      this.addWindowListener(windowListener);
    }

    const remove = /*#__PURE__*/function () {
      var _ref5 = (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        return _this.removeListener(eventName, listenerFunc);
      });

      return function remove() {
        return _ref5.apply(this, arguments);
      };
    }();

    const p = Promise.resolve({
      remove
    });
    Object.defineProperty(p, 'remove', {
      value: function () {
        var _ref6 = (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          console.warn(`Using addListener() without 'await' is deprecated.`);
          yield remove();
        });

        return function value() {
          return _ref6.apply(this, arguments);
        };
      }()
    });
    return p;
  }

  removeAllListeners() {
    var _this2 = this;

    return (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.listeners = {};

      for (const listener in _this2.windowListeners) {
        _this2.removeWindowListener(_this2.windowListeners[listener]);
      }

      _this2.windowListeners = {};
    })();
  }

  notifyListeners(eventName, data) {
    const listeners = this.listeners[eventName];

    if (listeners) {
      listeners.forEach(listener => listener(data));
    }
  }

  hasListeners(eventName) {
    return !!this.listeners[eventName].length;
  }

  registerWindowListener(windowEventName, pluginEventName) {
    this.windowListeners[pluginEventName] = {
      registered: false,
      windowEventName,
      pluginEventName,
      handler: event => {
        this.notifyListeners(pluginEventName, event);
      }
    };
  }

  unimplemented(msg = 'not implemented') {
    return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
  }

  unavailable(msg = 'not available') {
    return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
  }

  removeListener(eventName, listenerFunc) {
    var _this3 = this;

    return (0,A_newTest_weatherapp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const listeners = _this3.listeners[eventName];

      if (!listeners) {
        return;
      }

      const index = listeners.indexOf(listenerFunc);

      _this3.listeners[eventName].splice(index, 1); // If there are no more listeners for this type of event,
      // remove the window listener


      if (!_this3.listeners[eventName].length) {
        _this3.removeWindowListener(_this3.windowListeners[eventName]);
      }
    })();
  }

  addWindowListener(handle) {
    window.addEventListener(handle.windowEventName, handle.handler);
    handle.registered = true;
  }

  removeWindowListener(handle) {
    if (!handle) {
      return;
    }

    window.removeEventListener(handle.windowEventName, handle.handler);
    handle.registered = false;
  }

}

const WebView = /*#__PURE__*/registerPlugin('WebView');


/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background: #575A7F !important;\n}\n\n.customheader ion-icon {\n  margin: 1.2em;\n  text-align: center;\n  font-size: 24px;\n}\n\n.customheader p {\n  margin: 1em 0em;\n  text-align: start;\n  font-size: 24px;\n  font-family: \"poppins\";\n  font-style: normal;\n  font-weight: 600;\n  font-size: 24px;\n  line-height: 36px;\n}\n\n.searchbar ion-item {\n  width: 90%;\n  margin: 0% 5%;\n  --background: #1A1C49!important;\n  --border-radius: 15px;\n}\n\n.searchbar ion-item ion-input {\n  --placeholder-font-weight: 600;\n  --placeholder-color: #575A7F;\n}\n\n.searchbar ion-item ion-icon {\n  color: #575A7F;\n}\n\n.detailcard {\n  width: 90%;\n  margin: 2% 5%;\n}\n\n.detailcard ion-card {\n  --background:#1A1C49;\n  border-radius: 15px;\n  margin: 0%;\n}\n\n.detailcard .dateday {\n  padding: 5%;\n  padding-bottom: 0%;\n  display: flex;\n}\n\n.detailcard .dateday .textday {\n  margin: 0px;\n  flex: 1;\n  text-align: start;\n  color: #FFFFFF;\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 600;\n  font-size: 16px;\n  line-height: 24px;\n}\n\n.detailcard .dateday .textdate {\n  margin: 0%;\n  text-align: end;\n  flex: 1;\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 12px;\n  line-height: 18px;\n  color: #FFFFFF;\n}\n\n.detailcard .weatherdata {\n  padding: 0% 5%;\n  padding-top: 0%;\n  display: flex;\n}\n\n.detailcard .weatherdata .text {\n  flex: 1;\n  font-size: 56px;\n  margin: 0.2em 0em;\n  color: #FFFFFF;\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 500;\n  white-space: nowrap;\n}\n\n.detailcard .weatherdata .text .plus {\n  font-size: 56px;\n  color: #FFFFFF;\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 500;\n  white-space: nowrap;\n}\n\n.detailcard .weatherdata .text span {\n  font-size: 22px;\n  font-weight: 400;\n  color: #FED55B;\n  vertical-align: text-top;\n  margin: -10px;\n}\n\n.detailcard .weatherdata .image {\n  flex: 1;\n  text-align: right;\n}\n\n.detailcard .weatherdata .image img {\n  margin: 0.2em 0em;\n  width: 100px;\n  height: 90px;\n}\n\n.detailcard .location {\n  width: 100%;\n  text-align: center;\n  color: #FFFFFF;\n}\n\n.detailcard .location p {\n  font-size: 16px;\n  margin: 0%;\n  margin-bottom: 5px;\n}\n\n.detailcard .location p ion-icon {\n  font-size: 20px;\n  margin-right: 5px;\n}\n\n.gridcard {\n  width: 90%;\n  margin: 3% 5%;\n}\n\n.gridcard .humidity {\n  background: #1A1C49;\n  border-radius: 15px;\n  padding: 8%;\n  margin-right: 3%;\n  height: 100%;\n}\n\n.gridcard .humidity ion-grid {\n  padding: 0%;\n}\n\n.gridcard .humidity img {\n  width: 30px;\n  height: 30px;\n}\n\n.gridcard .humidity p {\n  font-size: 12px;\n  color: #FFFFFF;\n  margin: 0%;\n}\n\n.gridcard .humidity .value {\n  font-weight: 700;\n  font-size: 17px;\n}\n\n.gridcard .presure {\n  background: #1A1C49;\n  border-radius: 15px;\n  padding: 8%;\n  margin-left: 3%;\n  height: 100%;\n}\n\n.gridcard .presure ion-grid {\n  padding: 0%;\n}\n\n.gridcard .presure img {\n  width: 30px;\n  height: 30px;\n}\n\n.gridcard .presure p {\n  font-size: 12px;\n  color: #FFFFFF;\n  margin: 0%;\n}\n\n.gridcard .presure .value {\n  font-weight: 700;\n  font-size: 17px;\n}\n\n.nextdaygrid {\n  width: 90%;\n  margin: 0% 5%;\n}\n\n.nextdaygrid ion-card {\n  margin: 0%;\n  background: #1A1C49;\n  border-radius: 15px;\n  color: #FFFFFF;\n  padding: 10%;\n  height: 100%;\n}\n\n.nextdaygrid ion-card .text {\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 24px;\n  line-height: 36px;\n  text-align: center;\n}\n\n.nextdaygrid ion-card .text span {\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 36px;\n}\n\n.nextdaygrid ion-card p {\n  font-family: \"Poppins\";\n  font-style: normal;\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 21px;\n  text-align: center;\n  margin: 0%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0NBQUE7QUFDRjs7QUFJRztFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFETDs7QUFJRztFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFGTDs7QUFRRTtFQUNFLFVBQUE7RUFDQSxhQUFBO0VBQ0EsK0JBQUE7RUFDQSxxQkFBQTtBQUxKOztBQU9JO0VBQ0UsOEJBQUE7RUFDQSw0QkFBQTtBQUxOOztBQVFJO0VBQ0UsY0FBQTtBQU5OOztBQVdBO0VBQ0UsVUFBQTtFQUNBLGFBQUE7QUFSRjs7QUFTRTtFQUNFLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0FBUEo7O0FBVUU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FBUko7O0FBU0k7RUFDRSxXQUFBO0VBQ0EsT0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQVBOOztBQVNJO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSxPQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQVBOOztBQVlFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBVko7O0FBWUk7RUFDRSxPQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBVk47O0FBV007RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBVFI7O0FBWU07RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7RUFDQSxhQUFBO0FBVlI7O0FBY0k7RUFDRSxPQUFBO0VBQ0EsaUJBQUE7QUFaTjs7QUFhSztFQUNDLGlCQUFBO0VBQ0MsWUFBQTtFQUNBLFlBQUE7QUFYUDs7QUFpQkU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBZko7O0FBZ0JJO0VBQ0UsZUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtBQWROOztBQWVNO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBYlI7O0FBb0JBO0VBQ0ksVUFBQTtFQUNBLGFBQUE7QUFqQko7O0FBbUJFO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFqQko7O0FBa0JJO0VBQ0UsV0FBQTtBQWhCTjs7QUFrQkk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQWhCTjs7QUFrQkk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7QUFoQk47O0FBa0JJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBaEJOOztBQW9CRTtFQUNFLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUFsQko7O0FBbUJJO0VBQ0UsV0FBQTtBQWpCTjs7QUFtQkk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQWpCTjs7QUFtQkk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7QUFqQk47O0FBbUJJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBakJOOztBQXNCQTtFQUNFLFVBQUE7RUFDQSxhQUFBO0FBbkJGOztBQXFCRTtFQUNFLFVBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBbkJKOztBQXFCSTtFQUNFLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBbkJOOztBQXVCTTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBckJSOztBQXlCSTtFQUNFLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQXZCTiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6ICM1NzVBN0YgIWltcG9ydGFudDtcbn1cblxuLmN1c3RvbWhlYWRlcntcblxuICAgaW9uLWljb257XG4gICAgIG1hcmdpbjogMS4yZW07XG4gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgfVxuXG4gICBwe1xuICAgICBtYXJnaW46IDFlbSAwZW07XG4gICAgIHRleHQtYWxpZ246IHN0YXJ0O1xuICAgICBmb250LXNpemU6IDI0cHg7XG4gICAgIGZvbnQtZmFtaWx5OiAncG9wcGlucyc7XG4gICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICBsaW5lLWhlaWdodDogMzZweDtcbiAgIH1cbn1cblxuLnNlYXJjaGJhcntcbiAgXG4gIGlvbi1pdGVte1xuICAgIHdpZHRoOiA5MCU7XG4gICAgbWFyZ2luOiAwJSA1JTtcbiAgICAtLWJhY2tncm91bmQ6ICMxQTFDNDkhaW1wb3J0YW50O1xuICAgIC0tYm9yZGVyLXJhZGl1czogMTVweDtcblxuICAgIGlvbi1pbnB1dHtcbiAgICAgIC0tcGxhY2Vob2xkZXItZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIC0tcGxhY2Vob2xkZXItY29sb3I6ICM1NzVBN0Y7XG4gICAgfVxuXG4gICAgaW9uLWljb257XG4gICAgICBjb2xvcjojNTc1QTdGO1xuICAgIH1cbiAgfVxufVxuXG4uZGV0YWlsY2FyZHtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luOiAyJSA1JTtcbiAgaW9uLWNhcmR7XG4gICAgLS1iYWNrZ3JvdW5kOiMxQTFDNDk7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICBtYXJnaW46IDAlO1xuICB9XG5cbiAgLmRhdGVkYXl7XG4gICAgcGFkZGluZzogNSU7XG4gICAgcGFkZGluZy1ib3R0b206IDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgLnRleHRkYXl7XG4gICAgICBtYXJnaW46IDBweDtcbiAgICAgIGZsZXg6IDE7XG4gICAgICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJztcbiAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjRweDtcbiAgICB9XG4gICAgLnRleHRkYXRle1xuICAgICAgbWFyZ2luOiAwJTtcbiAgICAgIHRleHQtYWxpZ246IGVuZDtcbiAgICAgIGZsZXg6IDE7XG4gICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnO1xuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxOHB4O1xuICAgICAgY29sb3I6ICNGRkZGRkY7XG4gICAgfVxuICB9XG5cblxuICAud2VhdGhlcmRhdGF7XG4gICAgcGFkZGluZzogMCUgNSU7XG4gICAgcGFkZGluZy10b3A6IDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gIFxuICAgIC50ZXh0e1xuICAgICAgZmxleDogMTtcbiAgICAgIGZvbnQtc2l6ZTogNTZweDtcbiAgICAgIG1hcmdpbjogMC4yZW0gMGVtO1xuICAgICAgY29sb3I6ICNGRkZGRkY7XG4gICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnO1xuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAucGx1c3tcbiAgICAgICAgZm9udC1zaXplOiA1NnB4O1xuICAgICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJztcbiAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgfVxuXG4gICAgICBzcGFue1xuICAgICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICAgIGNvbG9yOiNGRUQ1NUI7XG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiB0ZXh0LXRvcDtcbiAgICAgICAgbWFyZ2luOiAtMTBweDtcbiAgICAgIH1cbiAgICB9XG4gIFxuICAgIC5pbWFnZXtcbiAgICAgIGZsZXg6IDE7XG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgaW1ne1xuICAgICAgbWFyZ2luOiAwLjJlbSAwZW07XG4gICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgIGhlaWdodDogOTBweDtcbiAgICAgfVxuICAgICBcbiAgICB9XG4gIH1cblxuICAubG9jYXRpb257XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgIHB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBtYXJnaW46MCU7XG4gICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICBpb24taWNvbntcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuXG4uZ3JpZGNhcmR7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBtYXJnaW46IDMlIDUlO1xuXG4gIC5odW1pZGl0eXtcbiAgICBiYWNrZ3JvdW5kOiAjMUExQzQ5O1xuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gICAgcGFkZGluZzogOCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAzJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgaW9uLWdyaWR7XG4gICAgICBwYWRkaW5nOiAwJTtcbiAgICB9XG4gICAgaW1ne1xuICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICBoZWlnaHQ6IDMwcHg7XG4gICAgfVxuICAgIHB7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgIG1hcmdpbjogMCU7XG4gICAgfVxuICAgIC52YWx1ZXtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgfVxuICB9XG5cbiAgLnByZXN1cmV7XG4gICAgYmFja2dyb3VuZDogIzFBMUM0OTtcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICAgIHBhZGRpbmc6IDglO1xuICAgIG1hcmdpbi1sZWZ0OiAzJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgaW9uLWdyaWR7XG4gICAgICBwYWRkaW5nOiAwJTtcbiAgICB9XG4gICAgaW1ne1xuICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICBoZWlnaHQ6IDMwcHg7XG4gICAgfVxuICAgIHB7XG4gICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICAgIG1hcmdpbjogMCU7XG4gICAgfVxuICAgIC52YWx1ZXtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgfVxuICB9XG59XG5cbi5uZXh0ZGF5Z3JpZHtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luOiAwJSA1JTtcblxuICBpb24tY2FyZHtcbiAgICBtYXJnaW46IDAlO1xuICAgIGJhY2tncm91bmQ6ICMxQTFDNDk7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICBjb2xvcjogI0ZGRkZGRjtcbiAgICBwYWRkaW5nOiAxMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuXG4gICAgLnRleHR7XG4gICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnO1xuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAzNnB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgIFxuXG4gICAgICBzcGFue1xuICAgICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAzNnB4O1xuICAgICAgfVxuICAgIH1cblxuICAgIHB7XG4gICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnO1xuICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAyMXB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgbWFyZ2luOiAwJTtcbiAgICB9XG4gIH1cbn0iXX0= */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n\n  <ion-grid>\n    <ion-row class=\"customheader\">\n      <ion-col size=\"3\">\n        <ion-icon name=\"apps-sharp\"></ion-icon>\n      </ion-col>\n      <ion-col>\n       <p> Weather Forcast </p> \n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"searchbar\">\n      <ion-col>\n       <ion-item>\n        <ion-icon name=\"search-outline\" slot=\"end\" (click)=\"getname()\" ></ion-icon>\n        <ion-input placeholder=\"Search Your City\" type=\"text\" [(ngModel)]=\"city\" (keyup.enter)=\"getname()\"></ion-input>\n       </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <div *ngIf=\"citywether\">\n    <ion-row class=\"detailcard\">\n      <ion-col>\n        <ion-card>\n          <div class=\"dateday\">\n            <p class=\"textday\">Today</p>\n            <p class=\"textdate\">{{localtime}}</p>\n          </div>\n\n          <div class=\"weatherdata\">\n            <p class=\"text\"> <span class=\"plus\" *ngIf=\"citywether.Temperature.Metric.Value > 1\"> + </span>{{citywether.Temperature.Metric.Value}} <span class=\"unit\">°C</span> </p>\n            <div class=\"image\">\n              <img  [src]='img'>\n            </div>\n          </div>\n          <div class=\"location\">\n            <p>  <ion-icon name=\"location-sharp\"></ion-icon> {{locationdata.EnglishName}}, {{locationdata.Country.EnglishName}} </p>\n          </div>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"gridcard\">\n      <ion-col>\n        <div class=\"humidity\">\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"4\" style=\"text-align: end;\">\n                <img src=\"assets/images/humidity.png\">\n              </ion-col>\n              <ion-col>\n                <p class=\"value\">\n                  {{citywether.IndoorRelativeHumidity}}%\n                </p>\n                <p>\n                  Humidity\n                </p>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"presure\">\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"4\" style=\"text-align: end;\">\n                <img src=\"assets/images/pressure.png\">\n              </ion-col>\n              <ion-col>\n                <p class=\"value\">\n                  {{citywether.Pressure.Metric.Value}}{{citywether.Pressure.Metric.Unit}}\n                </p>\n                <p>\n                  Pressure\n                </p>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n    </ion-row>\n\n  </div>\n\n  <div *ngIf=\"citywether\">\n    <ion-row class=\"nextdaygrid\">\n      <ion-col *ngFor=\"let a of forecastdata | slice:0:3; let i = index\">\n        <ion-card>\n          <div>\n            <p class=\"text\"> {{ getCelsius(a.RealFeelTemperature.Maximum.Value) }} <span>°C</span></p>\n            <p>{{ getDay(a?.Date) }}</p>\n          </div>\n        </ion-card>\n      </ion-col>\n      <!-- <ion-col>\n        <ion-card style=\"margin-right: 10%;\">\n          <div>\n            <p class=\"text\">+30 <span>°C</span></p>\n            <p>Saturday</p>\n          </div>\n        </ion-card>\n      </ion-col>\n      <ion-col>\n        <ion-card>\n          <div>\n            <p class=\"text\">+30 <span>°C</span></p>\n            <p>sunday</p>\n          </div>\n        </ion-card>\n      </ion-col> -->\n    </ion-row>\n  </div>\n  </ion-grid>\n \n</ion-content>\n";

/***/ }),

/***/ 3659:
/*!***************************************************!*\
  !*** ./node_modules/dateformat/lib/dateformat.js ***!
  \***************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ dateFormat),
/* harmony export */   "masks": () => (/* binding */ masks),
/* harmony export */   "i18n": () => (/* binding */ i18n),
/* harmony export */   "formatTimezone": () => (/* binding */ formatTimezone)
/* harmony export */ });
var token=/d{1,4}|D{3,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|W{1,2}|[LlopSZN]|"[^"]*"|'[^']*'/g;var timezone=/\b(?:[A-Z]{1,3}[A-Z][TC])(?:[-+]\d{4})?|((?:Australian )?(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time)\b/g;var timezoneClip=/[^-+\dA-Z]/g;function dateFormat(date,mask,utc,gmt){if(arguments.length===1&&typeof date==="string"&&!/\d/.test(date)){mask=date;date=undefined}date=date||date===0?date:new Date;if(!(date instanceof Date)){date=new Date(date)}if(isNaN(date)){throw TypeError("Invalid date")}mask=String(masks[mask]||mask||masks["default"]);var maskSlice=mask.slice(0,4);if(maskSlice==="UTC:"||maskSlice==="GMT:"){mask=mask.slice(4);utc=true;if(maskSlice==="GMT:"){gmt=true}}var _=function _(){return utc?"getUTC":"get"};var _d=function d(){return date[_()+"Date"]()};var D=function D(){return date[_()+"Day"]()};var _m=function m(){return date[_()+"Month"]()};var y=function y(){return date[_()+"FullYear"]()};var _H=function H(){return date[_()+"Hours"]()};var _M=function M(){return date[_()+"Minutes"]()};var _s=function s(){return date[_()+"Seconds"]()};var _L=function L(){return date[_()+"Milliseconds"]()};var _o=function o(){return utc?0:date.getTimezoneOffset()};var _W=function W(){return getWeek(date)};var _N=function N(){return getDayOfWeek(date)};var flags={d:function d(){return _d()},dd:function dd(){return pad(_d())},ddd:function ddd(){return i18n.dayNames[D()]},DDD:function DDD(){return getDayName({y:y(),m:_m(),d:_d(),_:_(),dayName:i18n.dayNames[D()],short:true})},dddd:function dddd(){return i18n.dayNames[D()+7]},DDDD:function DDDD(){return getDayName({y:y(),m:_m(),d:_d(),_:_(),dayName:i18n.dayNames[D()+7]})},m:function m(){return _m()+1},mm:function mm(){return pad(_m()+1)},mmm:function mmm(){return i18n.monthNames[_m()]},mmmm:function mmmm(){return i18n.monthNames[_m()+12]},yy:function yy(){return String(y()).slice(2)},yyyy:function yyyy(){return pad(y(),4)},h:function h(){return _H()%12||12},hh:function hh(){return pad(_H()%12||12)},H:function H(){return _H()},HH:function HH(){return pad(_H())},M:function M(){return _M()},MM:function MM(){return pad(_M())},s:function s(){return _s()},ss:function ss(){return pad(_s())},l:function l(){return pad(_L(),3)},L:function L(){return pad(Math.floor(_L()/10))},t:function t(){return _H()<12?i18n.timeNames[0]:i18n.timeNames[1]},tt:function tt(){return _H()<12?i18n.timeNames[2]:i18n.timeNames[3]},T:function T(){return _H()<12?i18n.timeNames[4]:i18n.timeNames[5]},TT:function TT(){return _H()<12?i18n.timeNames[6]:i18n.timeNames[7]},Z:function Z(){return gmt?"GMT":utc?"UTC":formatTimezone(date)},o:function o(){return(_o()>0?"-":"+")+pad(Math.floor(Math.abs(_o())/60)*100+Math.abs(_o())%60,4)},p:function p(){return(_o()>0?"-":"+")+pad(Math.floor(Math.abs(_o())/60),2)+":"+pad(Math.floor(Math.abs(_o())%60),2)},S:function S(){return["th","st","nd","rd"][_d()%10>3?0:(_d()%100-_d()%10!=10)*_d()%10]},W:function W(){return _W()},WW:function WW(){return pad(_W())},N:function N(){return _N()}};return mask.replace(token,function(match){if(match in flags){return flags[match]()}return match.slice(1,match.length-1)})}var masks={default:"ddd mmm dd yyyy HH:MM:ss",shortDate:"m/d/yy",paddedShortDate:"mm/dd/yyyy",mediumDate:"mmm d, yyyy",longDate:"mmmm d, yyyy",fullDate:"dddd, mmmm d, yyyy",shortTime:"h:MM TT",mediumTime:"h:MM:ss TT",longTime:"h:MM:ss TT Z",isoDate:"yyyy-mm-dd",isoTime:"HH:MM:ss",isoDateTime:"yyyy-mm-dd'T'HH:MM:sso",isoUtcDateTime:"UTC:yyyy-mm-dd'T'HH:MM:ss'Z'",expiresHeaderFormat:"ddd, dd mmm yyyy HH:MM:ss Z"};var i18n={dayNames:["Sun","Mon","Tue","Wed","Thu","Fri","Sat","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],monthNames:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","January","February","March","April","May","June","July","August","September","October","November","December"],timeNames:["a","p","am","pm","A","P","AM","PM"]};var pad=function pad(val){var len=arguments.length>1&&arguments[1]!==undefined?arguments[1]:2;return String(val).padStart(len,"0")};var getDayName=function getDayName(_ref){var y=_ref.y,m=_ref.m,d=_ref.d,_=_ref._,dayName=_ref.dayName,_ref$short=_ref["short"],_short=_ref$short===void 0?false:_ref$short;var today=new Date;var yesterday=new Date;yesterday.setDate(yesterday[_+"Date"]()-1);var tomorrow=new Date;tomorrow.setDate(tomorrow[_+"Date"]()+1);var today_d=function today_d(){return today[_+"Date"]()};var today_m=function today_m(){return today[_+"Month"]()};var today_y=function today_y(){return today[_+"FullYear"]()};var yesterday_d=function yesterday_d(){return yesterday[_+"Date"]()};var yesterday_m=function yesterday_m(){return yesterday[_+"Month"]()};var yesterday_y=function yesterday_y(){return yesterday[_+"FullYear"]()};var tomorrow_d=function tomorrow_d(){return tomorrow[_+"Date"]()};var tomorrow_m=function tomorrow_m(){return tomorrow[_+"Month"]()};var tomorrow_y=function tomorrow_y(){return tomorrow[_+"FullYear"]()};if(today_y()===y&&today_m()===m&&today_d()===d){return _short?"Tdy":"Today"}else if(yesterday_y()===y&&yesterday_m()===m&&yesterday_d()===d){return _short?"Ysd":"Yesterday"}else if(tomorrow_y()===y&&tomorrow_m()===m&&tomorrow_d()===d){return _short?"Tmw":"Tomorrow"}return dayName};var getWeek=function getWeek(date){var targetThursday=new Date(date.getFullYear(),date.getMonth(),date.getDate());targetThursday.setDate(targetThursday.getDate()-(targetThursday.getDay()+6)%7+3);var firstThursday=new Date(targetThursday.getFullYear(),0,4);firstThursday.setDate(firstThursday.getDate()-(firstThursday.getDay()+6)%7+3);var ds=targetThursday.getTimezoneOffset()-firstThursday.getTimezoneOffset();targetThursday.setHours(targetThursday.getHours()-ds);var weekDiff=(targetThursday-firstThursday)/(864e5*7);return 1+Math.floor(weekDiff)};var getDayOfWeek=function getDayOfWeek(date){var dow=date.getDay();if(dow===0){dow=7}return dow};var formatTimezone=function formatTimezone(date){return(String(date).match(timezone)||[""]).pop().replace(timezoneClip,"").replace(/GMT\+0000/g,"UTC")};

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map